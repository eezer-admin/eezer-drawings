# eezer-drawings
This is the cad model of the Eezer motorcyckle  ambulance wagon. The purpose of the repository is to provide manufacturers with the latest model and also invite engineers to further develop the wagon. The aim of the project is to create fast transport to maternal clinics in rural parts in Africa to provide safe births. See information about the project at https://www.eezer.org/ The drawing is editable with the opensource program Freecad3d, it can be downloaded here: https://www.freecadweb.org/

